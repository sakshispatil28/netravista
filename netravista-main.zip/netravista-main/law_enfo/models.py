from django.contrib.auth.models import AbstractUser
from django.db import models

class LawEnforcementUser(AbstractUser):
    picture = models.ImageField(upload_to='profile_pictures/', blank=True, null=True)
    badge_number = models.CharField(max_length=20, unique=True)
    department = models.CharField(max_length=100)
    rank = models.CharField(max_length=50)
    contact_number = models.CharField(max_length=15)