from django.apps import AppConfig


class LawEnfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'law_enfo'
