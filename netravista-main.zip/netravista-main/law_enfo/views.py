from django.shortcuts import render, redirect
from django.contrib import auth, messages

def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            
            # Ensure the user is authenticated before redirecting to the dashboard
            if request.user.is_authenticated:
                return redirect('dashboard')
            else:
                messages.error(request, 'Authentication failed. Please try again.')
        else:
            messages.error(request, 'Invalid username or password. Please try again.')
            # Log authentication failure to help identify potential issues
            print(f"Authentication failed for user {username}")

    return render(request, 'login.html')


def dashboard(request):
    return render(request, 'dashboard.html')

def logout(request):
    auth.logout(request)
    return redirect('login')